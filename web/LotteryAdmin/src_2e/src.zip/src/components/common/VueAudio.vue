<template>
    <div>
        <audio src="../../assets/mp3/b.mp3" controls="controls"></audio>
    </div>
</template>

<script>
    export default {
        name: 'VueAudio'
    };
</script>

<style scoped>

</style>