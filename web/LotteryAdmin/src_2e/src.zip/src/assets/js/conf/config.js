export default {
    baseApi: process.env.VUE_APP_API,
    token: process.env.VUE_APP_TOKEN
};